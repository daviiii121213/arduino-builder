{
  "option_gameguid": "98c70204-cf01-4b6c-aa10-4c2c27543da0",
  "option_game_speed": 60,
  "option_mips_for_3d_textures": false,
  "option_draw_colour": 4294967295,
  "option_window_colour": 255,
  "option_steam_app_id": "0",
  "option_sci_usesci": false,
  "option_author": "",
  "option_lastchanged": "",
  "option_spine_licence": false,
  "resourceVersion": "1.2",
  "name": "Main",
  "tags": [],
  "resourceType": "GMMainOptions"
}