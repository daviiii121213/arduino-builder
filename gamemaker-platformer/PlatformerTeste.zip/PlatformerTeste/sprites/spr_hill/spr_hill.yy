{
  "bboxMode": 0,
  "collisionKind": 1,
  "type": 0,
  "origin": 0,
  "preMultiplyAlpha": false,
  "edgeFiltering": false,
  "collisionTolerance": 0,
  "swfPrecision": 2.525,
  "bbox_left": 0,
  "bbox_right": 255,
  "bbox_top": 0,
  "bbox_bottom": 127,
  "HTile": false,
  "VTile": false,
  "For3D": false,
  "width": 256,
  "height": 128,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "swatchColours": null,
  "gridX": 0,
  "gridY": 0,
  "frames": [
    {
      "compositeImage": {
        "FrameId": {
          "name": "acb29b01-f519-4ba2-95f6-586444421576",
          "path": "sprites/spr_hill/spr_hill.yy"
        },
        "LayerId": null,
        "resourceVersion": "1.0",
        "name": "imported",
        "tags": [],
        "resourceType": "GMSpriteBitmap"
      },
      "images": [
        {
          "FrameId": {
            "name": "acb29b01-f519-4ba2-95f6-586444421576",
            "path": "sprites/spr_hill/spr_hill.yy"
          },
          "LayerId": {
            "name": "dafe4199-c789-4a19-a105-d85d828565ac",
            "path": "sprites/spr_hill/spr_hill.yy"
          },
          "resourceVersion": "1.0",
          "name": "",
          "tags": [],
          "resourceType": "GMSpriteBitmap"
        }
      ],
      "parent": {
        "name": "spr_hill",
        "path": "sprites/spr_hill/spr_hill.yy"
      },
      "resourceVersion": "1.0",
      "name": "acb29b01-f519-4ba2-95f6-586444421576",
      "tags": [],
      "resourceType": "GMSpriteFrame"
    }
  ],
  "sequence": {
    "spriteId": {
      "name": "spr_hill",
      "path": "sprites/spr_hill/spr_hill.yy"
    },
    "timeUnits": 1,
    "playback": 1,
    "playbackSpeed": 1.0,
    "playbackSpeedType": 0,
    "autoRecord": true,
    "volume": 1.0,
    "length": 1.0,
    "events": {
      "Keyframes": [],
      "resourceVersion": "1.0",
      "resourceType": "KeyframeStore<MessageEventKeyframe>"
    },
    "moments": {
      "Keyframes": [],
      "resourceVersion": "1.0",
      "resourceType": "KeyframeStore<MomentsEventKeyframe>"
    },
    "tracks": [
      {
        "name": "frames",
        "spriteId": null,
        "keyframes": {
          "Keyframes": [
            {
              "id": "a51e938b-05ed-4848-8124-fbdb71f0cce2",
              "Key": 0.0,
              "Length": 1.0,
              "Stretch": false,
              "Disabled": false,
              "IsCreationKey": false,
              "Channels": {
                "0": {
                  "Id": {
                    "name": "acb29b01-f519-4ba2-95f6-586444421576",
                    "path": "sprites/spr_hill/spr_hill.yy"
                  },
                  "resourceVersion": "1.0",
                  "resourceType": "SpriteFrameKeyframe"
                }
              },
              "resourceVersion": "1.0",
              "resourceType": "Keyframe<SpriteFrameKeyframe>"
            }
          ],
          "resourceVersion": "1.0",
          "resourceType": "KeyframeStore<SpriteFrameKeyframe>"
        },
        "trackColour": 0,
        "inheritsTrackColour": true,
        "builtinName": 0,
        "traces": [],
        "visibleRange": null,
        "isCreationTrack": false,
        "modifiers": [],
        "tracks": [],
        "events": [],
        "resourceVersion": "1.0",
        "tags": [],
        "resourceType": "GMSpriteFramesTrack"
      }
    ],
    "visibleRange": null,
    "lockOrigin": false,
    "showBackdrop": true,
    "showBackdropImage": false,
    "backdropImagePath": "",
    "backdropImageOpacity": 0.5,
    "backdropWidth": 1366,
    "backdropHeight": 768,
    "backdropXOffset": 0.0,
    "backdropYOffset": 0.0,
    "xorigin": 0,
    "yorigin": 0,
    "eventToFunction": {},
    "eventStubScript": null,
    "parent": {
      "name": "spr_hill",
      "path": "sprites/spr_hill/spr_hill.yy"
    },
    "resourceVersion": "1.3",
    "name": "spr_hill",
    "tags": [],
    "resourceType": "GMSequence"
  },
  "layers": [
    {
      "visible": true,
      "isLocked": false,
      "blendMode": 0,
      "opacity": 100.0,
      "displayName": "default",
      "resourceVersion": "1.0",
      "name": "dafe4199-c789-4a19-a105-d85d828565ac",
      "tags": [],
      "resourceType": "GMImageLayer"
    }
  ],
  "nineSlice": null,
  "parent": {
    "name": "Sprites",
    "path": "folders/Sprites.yy"
  },
  "resourceVersion": "1.0",
  "name": "spr_hill",
  "tags": [],
  "resourceType": "GMSprite"
}