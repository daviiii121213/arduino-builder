{
  "bboxMode": 2,
  "collisionKind": 1,
  "type": 0,
  "origin": 0,
  "preMultiplyAlpha": false,
  "edgeFiltering": false,
  "collisionTolerance": 0,
  "swfPrecision": 2.525,
  "bbox_left": 2,
  "bbox_right": 20,
  "bbox_top": 0,
  "bbox_bottom": 63,
  "HTile": false,
  "VTile": false,
  "For3D": false,
  "width": 32,
  "height": 64,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "swatchColours": null,
  "gridX": 0,
  "gridY": 0,
  "frames": [
    {
      "compositeImage": {
        "FrameId": {
          "name": "dbef9620-c1bc-461b-aafe-3291fb8b7a4b",
          "path": "sprites/spr_flag/spr_flag.yy"
        },
        "LayerId": null,
        "resourceVersion": "1.0",
        "name": "imported",
        "tags": [],
        "resourceType": "GMSpriteBitmap"
      },
      "images": [
        {
          "FrameId": {
            "name": "dbef9620-c1bc-461b-aafe-3291fb8b7a4b",
            "path": "sprites/spr_flag/spr_flag.yy"
          },
          "LayerId": {
            "name": "93ba7a9c-5da6-459f-98a3-c2396e2955ad",
            "path": "sprites/spr_flag/spr_flag.yy"
          },
          "resourceVersion": "1.0",
          "name": "",
          "tags": [],
          "resourceType": "GMSpriteBitmap"
        }
      ],
      "parent": {
        "name": "spr_flag",
        "path": "sprites/spr_flag/spr_flag.yy"
      },
      "resourceVersion": "1.0",
      "name": "dbef9620-c1bc-461b-aafe-3291fb8b7a4b",
      "tags": [],
      "resourceType": "GMSpriteFrame"
    },
    {
      "compositeImage": {
        "FrameId": {
          "name": "2d42f4c2-cc05-4ce4-a872-9d1bc8e6f93a",
          "path": "sprites/spr_flag/spr_flag.yy"
        },
        "LayerId": null,
        "resourceVersion": "1.0",
        "name": "imported",
        "tags": [],
        "resourceType": "GMSpriteBitmap"
      },
      "images": [
        {
          "FrameId": {
            "name": "2d42f4c2-cc05-4ce4-a872-9d1bc8e6f93a",
            "path": "sprites/spr_flag/spr_flag.yy"
          },
          "LayerId": {
            "name": "93ba7a9c-5da6-459f-98a3-c2396e2955ad",
            "path": "sprites/spr_flag/spr_flag.yy"
          },
          "resourceVersion": "1.0",
          "name": "",
          "tags": [],
          "resourceType": "GMSpriteBitmap"
        }
      ],
      "parent": {
        "name": "spr_flag",
        "path": "sprites/spr_flag/spr_flag.yy"
      },
      "resourceVersion": "1.0",
      "name": "2d42f4c2-cc05-4ce4-a872-9d1bc8e6f93a",
      "tags": [],
      "resourceType": "GMSpriteFrame"
    }
  ],
  "sequence": {
    "spriteId": {
      "name": "spr_flag",
      "path": "sprites/spr_flag/spr_flag.yy"
    },
    "timeUnits": 1,
    "playback": 1,
    "playbackSpeed": 3.0,
    "playbackSpeedType": 0,
    "autoRecord": true,
    "volume": 1.0,
    "length": 2.0,
    "events": {
      "Keyframes": [],
      "resourceVersion": "1.0",
      "resourceType": "KeyframeStore<MessageEventKeyframe>"
    },
    "moments": {
      "Keyframes": [],
      "resourceVersion": "1.0",
      "resourceType": "KeyframeStore<MomentsEventKeyframe>"
    },
    "tracks": [
      {
        "name": "frames",
        "spriteId": null,
        "keyframes": {
          "Keyframes": [
            {
              "id": "1053600f-7a57-4a57-baf9-00cfb9f816bf",
              "Key": 0.0,
              "Length": 1.0,
              "Stretch": false,
              "Disabled": false,
              "IsCreationKey": false,
              "Channels": {
                "0": {
                  "Id": {
                    "name": "dbef9620-c1bc-461b-aafe-3291fb8b7a4b",
                    "path": "sprites/spr_flag/spr_flag.yy"
                  },
                  "resourceVersion": "1.0",
                  "resourceType": "SpriteFrameKeyframe"
                }
              },
              "resourceVersion": "1.0",
              "resourceType": "Keyframe<SpriteFrameKeyframe>"
            },
            {
              "id": "39783f7f-cbcf-423e-a307-7d10378c9e94",
              "Key": 1.0,
              "Length": 1.0,
              "Stretch": false,
              "Disabled": false,
              "IsCreationKey": false,
              "Channels": {
                "0": {
                  "Id": {
                    "name": "2d42f4c2-cc05-4ce4-a872-9d1bc8e6f93a",
                    "path": "sprites/spr_flag/spr_flag.yy"
                  },
                  "resourceVersion": "1.0",
                  "resourceType": "SpriteFrameKeyframe"
                }
              },
              "resourceVersion": "1.0",
              "resourceType": "Keyframe<SpriteFrameKeyframe>"
            }
          ],
          "resourceVersion": "1.0",
          "resourceType": "KeyframeStore<SpriteFrameKeyframe>"
        },
        "trackColour": 0,
        "inheritsTrackColour": true,
        "builtinName": 0,
        "traces": [],
        "visibleRange": null,
        "isCreationTrack": false,
        "modifiers": [],
        "tracks": [],
        "events": [],
        "resourceVersion": "1.0",
        "tags": [],
        "resourceType": "GMSpriteFramesTrack"
      }
    ],
    "visibleRange": null,
    "lockOrigin": false,
    "showBackdrop": true,
    "showBackdropImage": false,
    "backdropImagePath": "",
    "backdropImageOpacity": 0.5,
    "backdropWidth": 1366,
    "backdropHeight": 768,
    "backdropXOffset": 0.0,
    "backdropYOffset": 0.0,
    "xorigin": 0,
    "yorigin": 0,
    "eventToFunction": {},
    "eventStubScript": null,
    "parent": {
      "name": "spr_flag",
      "path": "sprites/spr_flag/spr_flag.yy"
    },
    "resourceVersion": "1.3",
    "name": "spr_flag",
    "tags": [],
    "resourceType": "GMSequence"
  },
  "layers": [
    {
      "visible": true,
      "isLocked": false,
      "blendMode": 0,
      "opacity": 100.0,
      "displayName": "default",
      "resourceVersion": "1.0",
      "name": "93ba7a9c-5da6-459f-98a3-c2396e2955ad",
      "tags": [],
      "resourceType": "GMImageLayer"
    }
  ],
  "nineSlice": null,
  "parent": {
    "name": "Sprites",
    "path": "folders/Sprites.yy"
  },
  "resourceVersion": "1.0",
  "name": "spr_flag",
  "tags": [],
  "resourceType": "GMSprite"
}