{
  "bboxMode": 2,
  "collisionKind": 1,
  "type": 0,
  "origin": 0,
  "preMultiplyAlpha": false,
  "edgeFiltering": false,
  "collisionTolerance": 0,
  "swfPrecision": 2.525,
  "bbox_left": 1,
  "bbox_right": 14,
  "bbox_top": 9,
  "bbox_bottom": 15,
  "HTile": false,
  "VTile": false,
  "For3D": false,
  "width": 16,
  "height": 16,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "swatchColours": null,
  "gridX": 0,
  "gridY": 0,
  "frames": [
    {
      "compositeImage": {
        "FrameId": {
          "name": "0f79ef20-6cd0-48f3-8552-e123d846096c",
          "path": "sprites/spr_spike/spr_spike.yy"
        },
        "LayerId": null,
        "resourceVersion": "1.0",
        "name": "imported",
        "tags": [],
        "resourceType": "GMSpriteBitmap"
      },
      "images": [
        {
          "FrameId": {
            "name": "0f79ef20-6cd0-48f3-8552-e123d846096c",
            "path": "sprites/spr_spike/spr_spike.yy"
          },
          "LayerId": {
            "name": "76a54aa6-83a1-4866-955d-ab0a93dcd7b7",
            "path": "sprites/spr_spike/spr_spike.yy"
          },
          "resourceVersion": "1.0",
          "name": "",
          "tags": [],
          "resourceType": "GMSpriteBitmap"
        }
      ],
      "parent": {
        "name": "spr_spike",
        "path": "sprites/spr_spike/spr_spike.yy"
      },
      "resourceVersion": "1.0",
      "name": "0f79ef20-6cd0-48f3-8552-e123d846096c",
      "tags": [],
      "resourceType": "GMSpriteFrame"
    }
  ],
  "sequence": {
    "spriteId": {
      "name": "spr_spike",
      "path": "sprites/spr_spike/spr_spike.yy"
    },
    "timeUnits": 1,
    "playback": 1,
    "playbackSpeed": 1.0,
    "playbackSpeedType": 0,
    "autoRecord": true,
    "volume": 1.0,
    "length": 1.0,
    "events": {
      "Keyframes": [],
      "resourceVersion": "1.0",
      "resourceType": "KeyframeStore<MessageEventKeyframe>"
    },
    "moments": {
      "Keyframes": [],
      "resourceVersion": "1.0",
      "resourceType": "KeyframeStore<MomentsEventKeyframe>"
    },
    "tracks": [
      {
        "name": "frames",
        "spriteId": null,
        "keyframes": {
          "Keyframes": [
            {
              "id": "1af0ea9f-a464-4cd1-aaa6-655dac2ead84",
              "Key": 0.0,
              "Length": 1.0,
              "Stretch": false,
              "Disabled": false,
              "IsCreationKey": false,
              "Channels": {
                "0": {
                  "Id": {
                    "name": "0f79ef20-6cd0-48f3-8552-e123d846096c",
                    "path": "sprites/spr_spike/spr_spike.yy"
                  },
                  "resourceVersion": "1.0",
                  "resourceType": "SpriteFrameKeyframe"
                }
              },
              "resourceVersion": "1.0",
              "resourceType": "Keyframe<SpriteFrameKeyframe>"
            }
          ],
          "resourceVersion": "1.0",
          "resourceType": "KeyframeStore<SpriteFrameKeyframe>"
        },
        "trackColour": 0,
        "inheritsTrackColour": true,
        "builtinName": 0,
        "traces": [],
        "visibleRange": null,
        "isCreationTrack": false,
        "modifiers": [],
        "tracks": [],
        "events": [],
        "resourceVersion": "1.0",
        "tags": [],
        "resourceType": "GMSpriteFramesTrack"
      }
    ],
    "visibleRange": null,
    "lockOrigin": false,
    "showBackdrop": true,
    "showBackdropImage": false,
    "backdropImagePath": "",
    "backdropImageOpacity": 0.5,
    "backdropWidth": 1366,
    "backdropHeight": 768,
    "backdropXOffset": 0.0,
    "backdropYOffset": 0.0,
    "xorigin": 0,
    "yorigin": 0,
    "eventToFunction": {},
    "eventStubScript": null,
    "parent": {
      "name": "spr_spike",
      "path": "sprites/spr_spike/spr_spike.yy"
    },
    "resourceVersion": "1.3",
    "name": "spr_spike",
    "tags": [],
    "resourceType": "GMSequence"
  },
  "layers": [
    {
      "visible": true,
      "isLocked": false,
      "blendMode": 0,
      "opacity": 100.0,
      "displayName": "default",
      "resourceVersion": "1.0",
      "name": "76a54aa6-83a1-4866-955d-ab0a93dcd7b7",
      "tags": [],
      "resourceType": "GMImageLayer"
    }
  ],
  "nineSlice": null,
  "parent": {
    "name": "Sprites",
    "path": "folders/Sprites.yy"
  },
  "resourceVersion": "1.0",
  "name": "spr_spike",
  "tags": [],
  "resourceType": "GMSprite"
}