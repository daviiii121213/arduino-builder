{
  "bboxMode": 2,
  "collisionKind": 1,
  "type": 0,
  "origin": 4,
  "preMultiplyAlpha": false,
  "edgeFiltering": false,
  "collisionTolerance": 0,
  "swfPrecision": 2.525,
  "bbox_left": 9,
  "bbox_right": 22,
  "bbox_top": 4,
  "bbox_bottom": 31,
  "HTile": false,
  "VTile": false,
  "For3D": false,
  "width": 32,
  "height": 32,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "swatchColours": null,
  "gridX": 0,
  "gridY": 0,
  "frames": [
    {
      "compositeImage": {
        "FrameId": {
          "name": "fc1d9512-2736-4608-baa8-f474937ba52c",
          "path": "sprites/spr_player_idle/spr_player_idle.yy"
        },
        "LayerId": null,
        "resourceVersion": "1.0",
        "name": "imported",
        "tags": [],
        "resourceType": "GMSpriteBitmap"
      },
      "images": [
        {
          "FrameId": {
            "name": "fc1d9512-2736-4608-baa8-f474937ba52c",
            "path": "sprites/spr_player_idle/spr_player_idle.yy"
          },
          "LayerId": {
            "name": "1828d6e9-79a7-4af6-a7c0-01f03b3e8154",
            "path": "sprites/spr_player_idle/spr_player_idle.yy"
          },
          "resourceVersion": "1.0",
          "name": "",
          "tags": [],
          "resourceType": "GMSpriteBitmap"
        }
      ],
      "parent": {
        "name": "spr_player_idle",
        "path": "sprites/spr_player_idle/spr_player_idle.yy"
      },
      "resourceVersion": "1.0",
      "name": "fc1d9512-2736-4608-baa8-f474937ba52c",
      "tags": [],
      "resourceType": "GMSpriteFrame"
    },
    {
      "compositeImage": {
        "FrameId": {
          "name": "2f9a18ec-e5b4-47d2-a475-2e888152f0bb",
          "path": "sprites/spr_player_idle/spr_player_idle.yy"
        },
        "LayerId": null,
        "resourceVersion": "1.0",
        "name": "imported",
        "tags": [],
        "resourceType": "GMSpriteBitmap"
      },
      "images": [
        {
          "FrameId": {
            "name": "2f9a18ec-e5b4-47d2-a475-2e888152f0bb",
            "path": "sprites/spr_player_idle/spr_player_idle.yy"
          },
          "LayerId": {
            "name": "1828d6e9-79a7-4af6-a7c0-01f03b3e8154",
            "path": "sprites/spr_player_idle/spr_player_idle.yy"
          },
          "resourceVersion": "1.0",
          "name": "",
          "tags": [],
          "resourceType": "GMSpriteBitmap"
        }
      ],
      "parent": {
        "name": "spr_player_idle",
        "path": "sprites/spr_player_idle/spr_player_idle.yy"
      },
      "resourceVersion": "1.0",
      "name": "2f9a18ec-e5b4-47d2-a475-2e888152f0bb",
      "tags": [],
      "resourceType": "GMSpriteFrame"
    }
  ],
  "sequence": {
    "spriteId": {
      "name": "spr_player_idle",
      "path": "sprites/spr_player_idle/spr_player_idle.yy"
    },
    "timeUnits": 1,
    "playback": 1,
    "playbackSpeed": 3.0,
    "playbackSpeedType": 0,
    "autoRecord": true,
    "volume": 1.0,
    "length": 2.0,
    "events": {
      "Keyframes": [],
      "resourceVersion": "1.0",
      "resourceType": "KeyframeStore<MessageEventKeyframe>"
    },
    "moments": {
      "Keyframes": [],
      "resourceVersion": "1.0",
      "resourceType": "KeyframeStore<MomentsEventKeyframe>"
    },
    "tracks": [
      {
        "name": "frames",
        "spriteId": null,
        "keyframes": {
          "Keyframes": [
            {
              "id": "abecffbd-9f82-4a66-8e72-ae7f281a9d28",
              "Key": 0.0,
              "Length": 1.0,
              "Stretch": false,
              "Disabled": false,
              "IsCreationKey": false,
              "Channels": {
                "0": {
                  "Id": {
                    "name": "fc1d9512-2736-4608-baa8-f474937ba52c",
                    "path": "sprites/spr_player_idle/spr_player_idle.yy"
                  },
                  "resourceVersion": "1.0",
                  "resourceType": "SpriteFrameKeyframe"
                }
              },
              "resourceVersion": "1.0",
              "resourceType": "Keyframe<SpriteFrameKeyframe>"
            },
            {
              "id": "d08f944e-5fe7-4f64-803f-2dad3f26b51b",
              "Key": 1.0,
              "Length": 1.0,
              "Stretch": false,
              "Disabled": false,
              "IsCreationKey": false,
              "Channels": {
                "0": {
                  "Id": {
                    "name": "2f9a18ec-e5b4-47d2-a475-2e888152f0bb",
                    "path": "sprites/spr_player_idle/spr_player_idle.yy"
                  },
                  "resourceVersion": "1.0",
                  "resourceType": "SpriteFrameKeyframe"
                }
              },
              "resourceVersion": "1.0",
              "resourceType": "Keyframe<SpriteFrameKeyframe>"
            }
          ],
          "resourceVersion": "1.0",
          "resourceType": "KeyframeStore<SpriteFrameKeyframe>"
        },
        "trackColour": 0,
        "inheritsTrackColour": true,
        "builtinName": 0,
        "traces": [],
        "visibleRange": null,
        "isCreationTrack": false,
        "modifiers": [],
        "tracks": [],
        "events": [],
        "resourceVersion": "1.0",
        "tags": [],
        "resourceType": "GMSpriteFramesTrack"
      }
    ],
    "visibleRange": null,
    "lockOrigin": false,
    "showBackdrop": true,
    "showBackdropImage": false,
    "backdropImagePath": "",
    "backdropImageOpacity": 0.5,
    "backdropWidth": 1366,
    "backdropHeight": 768,
    "backdropXOffset": 0.0,
    "backdropYOffset": 0.0,
    "xorigin": 16,
    "yorigin": 16,
    "eventToFunction": {},
    "eventStubScript": null,
    "parent": {
      "name": "spr_player_idle",
      "path": "sprites/spr_player_idle/spr_player_idle.yy"
    },
    "resourceVersion": "1.3",
    "name": "spr_player_idle",
    "tags": [],
    "resourceType": "GMSequence"
  },
  "layers": [
    {
      "visible": true,
      "isLocked": false,
      "blendMode": 0,
      "opacity": 100.0,
      "displayName": "default",
      "resourceVersion": "1.0",
      "name": "1828d6e9-79a7-4af6-a7c0-01f03b3e8154",
      "tags": [],
      "resourceType": "GMImageLayer"
    }
  ],
  "nineSlice": null,
  "parent": {
    "name": "Sprites",
    "path": "folders/Sprites.yy"
  },
  "resourceVersion": "1.0",
  "name": "spr_player_idle",
  "tags": [],
  "resourceType": "GMSprite"
}