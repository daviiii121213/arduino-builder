{
  "spriteId": {
    "name": "spr_dust",
    "path": "sprites/spr_dust/spr_dust.yy"
  },
  "solid": false,
  "visible": true,
  "spriteMaskId": null,
  "persistent": false,
  "parentObjectId": null,
  "physicsObject": false,
  "physicsSensor": false,
  "physicsShape": 1,
  "physicsGroup": 1,
  "physicsDensity": 0.5,
  "physicsRestitution": 0.1,
  "physicsLinearDamping": 0.1,
  "physicsAngularDamping": 0.1,
  "physicsFriction": 0.2,
  "physicsStartAwake": true,
  "physicsKinematic": false,
  "physicsShapePoints": [],
  "eventList": [
    {
      "isDnD": false,
      "eventNum": 0,
      "eventType": 0,
      "collisionObjectId": null,
      "parent": {
        "name": "obj_fx",
        "path": "objects/obj_fx/obj_fx.yy"
      },
      "resourceVersion": "1.0",
      "name": "",
      "tags": [],
      "resourceType": "GMEvent"
    },
    {
      "isDnD": false,
      "eventNum": 7,
      "eventType": 7,
      "collisionObjectId": null,
      "parent": {
        "name": "obj_fx",
        "path": "objects/obj_fx/obj_fx.yy"
      },
      "resourceVersion": "1.0",
      "name": "",
      "tags": [],
      "resourceType": "GMEvent"
    }
  ],
  "properties": [],
  "overriddenProperties": [],
  "parent": {
    "name": "Objects",
    "path": "folders/Objects.yy"
  },
  "resourceVersion": "1.0",
  "name": "obj_fx",
  "tags": [],
  "resourceType": "GMObject"
}